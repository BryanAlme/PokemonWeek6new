//
//  NetworkURL.swift
//  PocketMonster
//
//  Created by Christian Quicano on 4/20/22.
//

import Foundation

enum NetworkURL {
    static let pokemonsNamesURL = "https://pokeapi.co/api/v2/pokemon/?limit=100"
}
